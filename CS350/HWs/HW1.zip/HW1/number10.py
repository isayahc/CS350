foo = []  
for x in range(30):     
    if x%2 > 0:        
        if x%3 == 0:           
            foo.append(x) 
            print(foo) 

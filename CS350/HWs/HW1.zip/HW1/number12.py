ingredients = list(("chocolate", "peanut butter", "sugar", "banana", "strawberry", "vanilla", "honey"))
for x in ingredients:
    print
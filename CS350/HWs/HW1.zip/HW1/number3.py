weight = int(input("enter weight of luggage"))
if  weight >50:
    print("There is a $30 charge for luggage that heavy ")
else:
    print("Thank you for your business")
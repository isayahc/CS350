drinks = ["water", "orange juice", "tea", "coffee", "milk"] 
for d in drinks: 
    print("I like to drink", d) 